<?php
if (!defined('ABSPATH')) exit;
class DSS_Product_Collector {}
